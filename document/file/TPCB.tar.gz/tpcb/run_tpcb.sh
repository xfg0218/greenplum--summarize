#!/bin/bash
TPCB_HOME=$(cd "$(dirname "$1")"; pwd -P)
echo "tpcb home:" $TPCB_HOME

# modify factor here
SCALE_FACTOR=2000   #初始化数据量参数等于1初始化（10万）
DB_NAME=tpcb        #数据库
JOB=128              #这个值和cpu个数相关，一般设置为和CPU个数相同即可。
RUN_TIME=120        #测试时长，单位秒
PRINT_FREQUENCY=20  #日志输出频率为多少秒打印一次


#psql -c "create database tpcb"
createdb ${DB_NAME}
mkdir -p log
# modify jobs here
conn_arr=( 100 200 300 400 500 )
init=true
crud=true
select=true
update=true
insert=true

init_tpcb()
{
    # init tpcb
    pgbench -i -s $SCALE_FACTOR $DB_NAME > ./log/init.log 2>&1
}


crud_tpcb()
{
    # crud tpcb test
    for N in "${conn_arr[@]}"
    do	
    	echo "pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f crud.sql -p 5432 > ./log/gpdb_crud_$N.log 2>&1"
    	sleep 5
    	pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f crud.sql -p 5432 > ./log/gpdb_crud_$N.log 2>&1
    done
    
    echo "" > ./log/crud_res.log
    for N in "${conn_arr[@]}"
    do 
       client=`cat ./log/gpdb_crud_$N.log|grep "clients"|awk -F ":" '{print $2}'`
       tps=`cat ./log/gpdb_crud_$N.log|grep "excluding connections establishing"|awk -F "=" '{print $2}'|awk -F"(" '{print $1}'`
       scale=`cat ./log/gpdb_crud_$N.log|grep "scaling factor"|awk -F ":" '{print $2}'`
       echo "scale:"${scale} ,"client:"${client}, "tps:"${tps} >> ./log/crud_res.log
    done
}


select_tpcb()
{
    # select tpcb
    for N in "${conn_arr[@]}"
    do	
    	echo "pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} -S tpcb -p 5432 > ./log/gpdb_select_$N.log 2>&1"
    	sleep 5
    	pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} -S tpcb -p 5432 > ./log/gpdb_select_$N.log 2>&1
    done
    
    echo "" > ./log/select_res.log
    for N in "${conn_arr[@]}"
    do	
       client=`cat ./log/gpdb_select_$N.log |grep "clients"|awk -F ":" '{print $2}'`
       tps=`cat ./log/gpdb_select_$N.log |grep "excluding connections establishing"|awk -F "=" '{print $2}'|awk -F"(" '{print $1}'`
       scale=`cat ./log/gpdb_select_$N.log |grep "scaling factor"|awk -F ":" '{print $2}'`
       echo "scale:"${scale} ,"client:"${client}, "tps:"${tps} >> ./log/select_res.log
    done
}

insert_tpcb()
{
    # insert tpcb test
    for N in "${conn_arr[@]}"
    do	
        echo "pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f insert.sql -p 5432 > ./log/gpdb_insert_$N.log 2>&1"
    	sleep 5
        pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f insert.sql -p 5432 > ./log/gpdb_insert_$N.log 2>&1
    done
    
    echo "" > ./log/insert_res.log
    for N in "${conn_arr[@]}"
    do	
       client=`cat ./log/gpdb_insert_$N.log |grep "clients"|awk -F ":" '{print $2}'`
       tps=`cat ./log/gpdb_insert_$N.log |grep "excluding connections establishing"|awk -F "=" '{print $2}'|awk -F"(" '{print $1}'`
       scale=`cat ./log/gpdb_insert_$N.log |grep "scaling factor"|awk -F ":" '{print $2}'`
       echo "scale:"${scale} ,"client:"${client}, "tps:"${tps} >> ./log/insert_res.log
    done
}

update_tpcb()
{
    # update tpch 
    for N in "${conn_arr[@]}"
    do
        echo "pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f update.sql -p 5432 > ./log/gpdb_update_$N.log 2>&1"
        sleep 5
        pgbench -c $N -j ${JOB} -r -T ${RUN_TIME} -P ${PRINT_FREQUENCY} -s ${SCALE_FACTOR} $DB_NAME -f update.sql -p 5432 > ./log/gpdb_update_$N.log 2>&1
    done
    
    echo ""> ./log/update_res.log
    for N in "${conn_arr[@]}"
    do
       client=`cat ./log/gpdb_update_$N.log |grep "clients"|awk -F ":" '{print $2}'`
       tps=`cat ./log/gpdb_update_$N.log |grep "excluding connections establishing"|awk -F "=" '{print $2}'|awk -F"(" '{print $1}'`
       scale=`cat ./log/gpdb_update_$N.log |grep "scaling factor"|awk -F ":" '{print $2}'`
       echo "scale:"${scale} ,"client:"${client}, "tps:"${tps} >> ./log/update_res.log
    done
}


#init tpcb 
if [ "$init" == "true" ]; then
        echo "start init tpcb"
	init_tpcb
fi

# crud tpcb 
if [ "$crud" == "true" ]; then
        echo "start crud tpcb"
	crud_tpcb
fi

# select tpcb 
if [ "$select" == "true" ]; then
        echo "start select tpcb"
	select_tpcb
fi

# insert tpcb 
if [ "$insert" == "true" ]; then
        echo "start insert tpcb"
	insert_tpcb
fi

# update tpcb 
if [ "$update" == "true" ]; then
        echo "start update tpcb"
	update_tpcb
fi

