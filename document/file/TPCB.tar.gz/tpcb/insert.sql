\set nbranches random (1,1 * :scale)
\set ntellers random (1,10 * :scale)
\set naccounts random(1,100000 * :scale)
\set aid random (1,:naccounts)
\set bid random(1,:nbranches)
\set tid random(1,:ntellers)
\set delta random(-5000,5000)
INSERT INTO pgbench_history (tid, bid, aid, delta, mtime) VALUES (:tid, :bid, :aid, :delta, now());
