COPY tpch.part FROM :filename WITH DELIMITER '|' NULL '';
