COPY tpch.nation FROM :filename WITH DELIMITER '|' NULL '';
