COPY tpch.lineitem FROM :filename WITH DELIMITER '|' NULL '';
