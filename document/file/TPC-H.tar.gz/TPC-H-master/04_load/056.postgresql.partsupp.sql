COPY tpch.partsupp FROM :filename WITH DELIMITER '|' NULL '';
