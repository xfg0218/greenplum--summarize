COPY tpch.customer FROM :filename WITH DELIMITER '|' NULL '';
