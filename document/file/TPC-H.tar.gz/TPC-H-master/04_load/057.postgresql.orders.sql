COPY tpch.orders FROM :filename WITH DELIMITER '|' NULL '';
