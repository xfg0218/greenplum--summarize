COPY tpch.supplier FROM :filename WITH DELIMITER '|' NULL '';
