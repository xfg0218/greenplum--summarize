COPY tpch.region FROM :filename WITH DELIMITER '|' NULL '';
