REPO_URL="https://github.com/ymatrix-data/TPC-H"
ADMIN_USER="mxadmin"
INSTALL_DIR="/home/mxadmin/TPC-H-master"
EXPLAIN_ANALYZE="false"
RANDOM_DISTRIBUTION="false"
MULTI_USER_COUNT="1" 
GEN_DATA_SCALE="1"       #tpch的规模scale参数，需要根据客户的要求更改,1代表生成1GB的数据量
SINGLE_USER_ITERATIONS="1" #单用户模式下，运行SQL迭代次数
RUN_COMPILE_TPCH="true"    #编译gen,保持true即可，这一步骤会生成segment_hosts.txt文件，否则报错找不到这个文件
RUN_GEN_DATA="true"        #是否生成数据，true 生成，false 不生成
RUN_INIT="true"            #是否执行初始化，再次运行的时候，不需要重新初始化，就置为false
RUN_DDL="true"             #是否加载ddl
RUN_LOAD="true"            #是否加载数据
RUN_SQL="false"            #是否执行SQL
RUN_SINGLE_USER_REPORT="false"  #是否生成报告
RUN_MULTI_USER="false"     #是否运行多用户
RUN_MULTI_USER_REPORT="false" 
GREENPLUM_PATH="/usr/local/matrixdb/greenplum_path.sh"
SMALL_STORAGE="" # For region/nation, empty means heap
MEDIUM_STORAGE="with(appendonly=true, orientation=column)" # For customer/part/partsupp/supplier, eg: with(appendonly=true, orientation=column), empty means heap
LARGE_STORAGE="with(appendonly=true, orientation=column,  compresstype=zstd, COMPRESSLEVEL=1)" # For lineitem, eg: with(appendonly=true, orientation=column, compresstype=1z4), empty means heap
OPTIMIZER="off"
GEN_DATA_DIR="/home/mxadmin/TPC-H-master/generated"
EXT_HOST_DATA_DIR="~"
