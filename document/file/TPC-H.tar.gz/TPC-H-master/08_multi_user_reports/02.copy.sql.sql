COPY tpch_testing.sql FROM :LOGFILE WITH DELIMITER '|';
