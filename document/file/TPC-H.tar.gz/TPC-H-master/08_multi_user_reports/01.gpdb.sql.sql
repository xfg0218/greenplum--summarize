CREATE TABLE tpch_testing.sql
(id int, description varchar, tuples bigint, duration time)
DISTRIBUTED BY (id);
