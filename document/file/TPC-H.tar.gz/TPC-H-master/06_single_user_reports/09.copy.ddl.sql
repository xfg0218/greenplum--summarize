COPY tpch_reports.ddl FROM :LOGFILE WITH DELIMITER '|';
