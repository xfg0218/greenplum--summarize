CREATE TABLE tpch_reports.compile_tpch
(id int, description varchar, tuples bigint, duration time);
