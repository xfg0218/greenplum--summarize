CREATE TABLE tpch_reports.sql
(id int, description varchar, tuples bigint, duration time) 
DISTRIBUTED BY (id);
